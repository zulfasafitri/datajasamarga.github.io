 <?php 

 	$koneksi = mysqli_connect("localhost", "root", "", "indomobil") or die("Koneksi Ke Database Gagal");


  ?>